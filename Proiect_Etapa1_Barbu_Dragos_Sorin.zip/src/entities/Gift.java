package entities;

import enums.Category;

public final class Gift {
    private String productName;
    private double price;
    private Category category;

    public Gift(final String productName, final double price,
                final Category category) {
        this.productName = productName;
        this.price = price;
        this.category = category;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(final String productName) {
        this.productName = productName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(final double price) {
        this.price = price;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(final Category category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "Gift{"
                +
                "productName='" + productName
                + '\''
                +
                ", price=" + price
                +
                ", category=" + category
                +
                '}';
    }
}
